from django.contrib import admin
from .models import Shelter, Dog

admin.site.register(Shelter)
admin.site.register(Dog)
