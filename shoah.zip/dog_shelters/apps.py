from django.apps import AppConfig


class DogSheltersConfig(AppConfig):
    name = 'dog_shelters'
