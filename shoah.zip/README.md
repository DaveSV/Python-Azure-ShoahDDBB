



La aplicación construida "Shoa Database" corre en https://shoahddbb.azurewebsites.net

Python 3.8
Django 4.0

![image](https://user-images.githubusercontent.com/29576337/180628976-829acacc-dd09-4cc2-9500-580001f35129.png)

