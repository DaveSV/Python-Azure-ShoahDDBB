

La aplicación construida "Shoa Database" corre en https://as-django-app.herokuapp.com/shelter/1 y https://shoahddbb.azurewebsites.net

Python 3.8
Django 4.0

![image](https://user-images.githubusercontent.com/29576337/180589311-d0c7a116-cbd0-4682-b2dd-ab9161368c99.png)

