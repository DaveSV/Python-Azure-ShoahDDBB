﻿# Python-Django-c-digo-de-Micrisoft-Learn-Dog-Shelters

Django para crear sitios web controlados por datos.

Ruta de aprendizaje:

Compilar una aplicación.
Crear y administrar una base datos.
Configurar un superusuario para el sitio de administración.
Usar plantillas para crear páginas HTML dinámicas.
Diseñar formularios controlados por datos.

Tutorial: https://docs.microsoft.com/es-es/learn/paths/django-create-data-driven-websites/

La aplicación construida "Dog Shelter Application" corre en https://as-django-app.herokuapp.com/shelter/1
